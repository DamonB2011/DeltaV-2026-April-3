import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Videos table: stores uploaded video metadata
 */
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(), // S3 key
  fileUrl: text("fileUrl").notNull(), // S3 public URL
  fileSizeBytes: int("fileSizeBytes").notNull(),
  durationSeconds: int("durationSeconds"),
  fps: int("fps"),
  width: int("width"),
  height: int("height"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

/**
 * Analyses table: stores kinematics analysis results
 * All result columns are nullable - they are populated asynchronously by the physics engine
 */
export const analyses = mysqlTable("analyses", {
  id: int("id").autoincrement().primaryKey(),
  videoId: int("videoId").notNull().references(() => videos.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id),
  trackingMethod: varchar("trackingMethod", { length: 64 }).notNull(), // 'mog2' or 'csrt'
  pixelsPerMeter: int("pixelsPerMeter").notNull(),
  sgWindowLength: int("sgWindowLength").notNull(),
  sgPolynomialOrder: int("sgPolynomialOrder").notNull(),
  // Result columns - all nullable, populated after analysis completes
  framesTracked: int("framesTracked"),
  peakSpeed: int("peakSpeed"), // stored as integer (mm/s for precision)
  meanSpeed: int("meanSpeed"),
  peakAcceleration: int("peakAcceleration"),
  netDisplacement: int("netDisplacement"),
  pathLength: int("pathLength"),
  resultsJson: text("resultsJson"), // Full kinematics data as JSON
  hudGifKey: varchar("hudGifKey", { length: 512 }), // S3 key for HUD GIF
  hudGifUrl: text("hudGifUrl"), // S3 public URL for HUD GIF
  // Status tracking
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  errorMessage: text("errorMessage"), // only populated on failure
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = typeof analyses.$inferInsert;
