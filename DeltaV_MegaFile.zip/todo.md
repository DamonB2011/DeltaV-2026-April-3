# DeltaV Web Application — TODO

## Phase 1: Architecture & Setup
- [x] Initialize web-db-user project scaffold
- [x] Plan full-stack architecture (React + Express + Python backend)
- [ ] Set up Python physics engine module in backend

## Phase 2: Frontend UI
- [x] Build dark mode glassmorphic SaaS theme (Tailwind + CSS variables)
- [x] Create hero section with "AI-Powered Kinematics Engine" messaging
- [x] Implement video file uploader (.mp4, .mov)
- [ ] Build sidebar with tracking/filter configuration controls
- [ ] Create results dashboard layout (4 tabs)

## Phase 3: Backend Physics Engine
- [x] Integrate OpenCV CSRT tracker via subprocess
- [x] Integrate MOG2 background subtraction
- [x] Implement Savitzky-Golay filter wrapper
- [x] Implement numerical differentiation (velocity/acceleration)
- [x] Create HUD rendering pipeline (GIF with force vectors)

## Phase 4: Database Schema
- [x] Add `videos` table (user_id, filename, upload_url, created_at)
- [x] Add `analyses` table (video_id, tracking_method, scale_calibration, results_json)
- [x] Add database helper functions for CRUD operations

## Phase 5: API & Integration
- [x] Create tRPC procedures for videos and analyses
- [ ] Create tRPC procedure for video upload with S3
- [ ] Create tRPC procedure for analysis job submission
- [ ] Create tRPC procedure for analysis results retrieval
- [ ] Integrate S3 storage for video files and HUD GIFs
- [ ] Implement async job processing (queue or direct subprocess)

## Phase 5b: End-to-End Workflow (COMPLETE)
- [x] Implement tRPC video upload and analysis procedures
- [x] Build configuration sidebar (tracking method, S-G filter, calibration)
- [x] Create Plotly visualization components (3 charts + trajectory map)
- [x] Build results page with HUD video display and CSV export
- [x] Integrate frontend with backend pipeline (Analyzer page)
- [x] Test end-to-end workflow with vitest (12 tests passing)





## Phase 6: Full-Stack Integration (COMPLETE)
- [x] Enhance backend with real-time progress tracking
- [x] Implement frontend file upload with tRPC integration
- [x] Build functional results dashboard with live database data
- [x] Add CSV export functionality
- [x] Test end-to-end workflow (12 vitest tests passing)

## Future Enhancements
- [ ] Batch video processing
- [ ] Preset analysis templates
- [ ] WebSocket real-time progress updates
- [ ] Analysis history and comparison
- [ ] Custom export formats (PDF reports)
- [ ] Collaborative analysis sharing
