import { describe, expect, it, vi, beforeEach } from "vitest";
import { analysisRouter } from "./analysis";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("analysisRouter", () => {
  describe("uploadVideo", () => {
    it("should reject unauthenticated requests", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {} as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.uploadVideo({
          filename: "test.mp4",
          fileBase64: "base64data",
          fileSizeBytes: 1000,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should validate input schema", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.uploadVideo({
          filename: "",
          fileBase64: "base64data",
          fileSizeBytes: 1000,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject zero file size", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.uploadVideo({
          filename: "test.mp4",
          fileBase64: "base64data",
          fileSizeBytes: 0,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("submitAnalysis", () => {
    it("should reject unauthenticated requests", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {} as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.submitAnalysis({
          videoId: 1,
          trackingMethod: "mog2",
          pixelsPerMeter: 100,
          sgWindow: 11,
          sgPoly: 3,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should validate tracking method enum", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.submitAnalysis({
          videoId: 1,
          trackingMethod: "invalid" as any,
          pixelsPerMeter: 100,
          sgWindow: 11,
          sgPoly: 3,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject invalid S-G window", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.submitAnalysis({
          videoId: 1,
          trackingMethod: "mog2",
          pixelsPerMeter: 100,
          sgWindow: 3, // Too small
          sgPoly: 3,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject invalid S-G polynomial order", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.submitAnalysis({
          videoId: 1,
          trackingMethod: "mog2",
          pixelsPerMeter: 100,
          sgWindow: 11,
          sgPoly: 6, // Too high
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject zero pixels per meter", async () => {
      const ctx = createAuthContext();
      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.submitAnalysis({
          videoId: 1,
          trackingMethod: "mog2",
          pixelsPerMeter: 0,
          sgWindow: 11,
          sgPoly: 3,
        });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("listVideos", () => {
    it("should reject unauthenticated requests", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {} as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.listVideos();
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("listAnalyses", () => {
    it("should accept public requests", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {} as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = analysisRouter.createCaller(ctx);

      try {
        const result = await caller.listAnalyses({ videoId: 1 });
        expect(result).toBeDefined();
      } catch (error) {
        // Expected if database is not available
        expect(error).toBeDefined();
      }
    });

    it("should reject invalid video ID", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: {} as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };

      const caller = analysisRouter.createCaller(ctx);

      try {
        await caller.listAnalyses({ videoId: 0 });
        expect.fail("Should have thrown");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
