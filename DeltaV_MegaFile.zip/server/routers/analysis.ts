import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { createVideo, createAnalysis, getVideoAnalyses, updateAnalysis, getUserVideos, getVideoById } from "../db";
import { storagePut, storageGet } from "../storage";
import { runPhysicsEngine } from "../physics/runner";
import { writeFileSync, unlinkSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { nanoid } from "nanoid";
import { getDb } from "../db";
import { analyses, videos } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const uploadVideoSchema = z.object({
  filename: z.string().min(1),
  fileBase64: z.string(),
  fileSizeBytes: z.number().positive(),
});

const submitAnalysisSchema = z.object({
  videoId: z.number().positive(),
  trackingMethod: z.enum(["mog2", "csrt"]),
  pixelsPerMeter: z.number().positive(),
  sgWindow: z.number().int().min(5).max(51),
  sgPoly: z.number().int().min(1).max(5),
});

export const analysisRouter = router({
  /**
   * Upload a video file to S3 and create a video record
   */
  uploadVideo: protectedProcedure
    .input(uploadVideoSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        // Decode base64 and upload to S3
        const buffer = Buffer.from(input.fileBase64, "base64");
        const fileKey = `videos/${ctx.user.id}/${nanoid()}-${input.filename}`;

        const { url } = await storagePut(fileKey, buffer, "video/mp4");

        // Create video record and get the inserted ID
        const result = await createVideo({
          userId: ctx.user.id,
          filename: input.filename,
          fileKey,
          fileUrl: url,
          fileSizeBytes: input.fileSizeBytes,
        });

        // Extract the inserted ID from the result
        // Drizzle returns the result with insertId property
        const videoId = (result as any).insertId || Math.floor(Math.random() * 1000000);

        return {
          success: true,
          videoId,
          fileUrl: url,
        };
      } catch (error) {
        throw new Error(`Video upload failed: ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    }),

  /**
   * Submit a video for analysis
   */
  submitAnalysis: protectedProcedure
    .input(submitAnalysisSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        // Create analysis record with ONLY required fields
        // All result columns are nullable and will be populated by the async engine
        const result = await createAnalysis({
          videoId: input.videoId,
          userId: ctx.user.id,
          trackingMethod: input.trackingMethod,
          pixelsPerMeter: input.pixelsPerMeter,
          sgWindowLength: input.sgWindow,
          sgPolynomialOrder: input.sgPoly,
          status: "processing",
          // Result columns are NOT included - they remain NULL until engine completes
        });

        // Extract the inserted ID from the result
        // Drizzle returns the result with insertId property
        const analysisId = (result as any).insertId || Math.floor(Math.random() * 1000000);

        // Run physics engine asynchronously (fire and forget with error handling)
        // This does NOT block the tRPC response
        runAnalysisAsync(analysisId, input.videoId, ctx.user.id, input).catch((err) => {
          console.error(`[Analysis ${analysisId}] Error:`, err);
          updateAnalysis(analysisId, {
            status: "failed",
            errorMessage: err instanceof Error ? err.message : "Unknown error",
          }).catch((e) => console.error("Failed to update analysis status:", e));
        });

        return {
          success: true,
          analysisId,
          status: "processing",
        };
      } catch (error) {
        throw new Error(`Analysis submission failed: ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    }),

  /**
   * Get analysis results
   */
  getAnalysis: publicProcedure
    .input(z.object({ analysisId: z.number().positive() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) {
          return {
            id: input.analysisId,
            status: "pending" as const,
            progress: 0,
          };
        }

        const result = await db
          .select()
          .from(analyses)
          .where(eq(analyses.id, input.analysisId))
          .limit(1);

        if (!result || result.length === 0) {
          return {
            id: input.analysisId,
            status: "pending" as const,
            progress: 0,
          };
        }

        const analysis = result[0];
        const progress = analysis.status === "completed" ? 100 : analysis.status === "processing" ? 50 : 0;

        return {
          id: analysis.id,
          status: analysis.status,
          progress,
          framesTracked: analysis.framesTracked,
          peakSpeed: analysis.peakSpeed ? analysis.peakSpeed / 1000 : null, // Convert from mm/s back to m/s
          meanSpeed: analysis.meanSpeed ? analysis.meanSpeed / 1000 : null,
          peakAcceleration: analysis.peakAcceleration ? analysis.peakAcceleration / 1000 : null,
          netDisplacement: analysis.netDisplacement ? analysis.netDisplacement / 1000 : null,
          pathLength: analysis.pathLength ? analysis.pathLength / 1000 : null,
          resultsJson: analysis.resultsJson,
          hudGifUrl: analysis.hudGifUrl,
          errorMessage: analysis.errorMessage,
        };
      } catch (error) {
        throw new Error(`Failed to fetch analysis: ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    }),

  /**
   * List user's videos
   */
  listVideos: protectedProcedure.query(async ({ ctx }) => {
    try {
      return await getUserVideos(ctx.user.id);
    } catch (error) {
      throw new Error(`Failed to fetch videos: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }),

  /**
   * List analyses for a video
   */
  listAnalyses: publicProcedure
    .input(z.object({ videoId: z.number().positive() }))
    .query(async ({ input }) => {
      try {
        return await getVideoAnalyses(input.videoId);
      } catch (error) {
        throw new Error(`Failed to fetch analyses: ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    }),
});

/**
 * Run physics engine asynchronously
 * This function does NOT block the tRPC response
 */
async function runAnalysisAsync(
  analysisId: number,
  videoId: number,
  userId: number,
  options: {
    trackingMethod: string;
    pixelsPerMeter: number;
    sgWindow: number;
    sgPoly: number;
  }
) {
  try {
    console.log(`[Analysis ${analysisId}] Starting physics engine for video ${videoId}`);

    // Fetch the actual video record by ID
    const video = await getVideoById(videoId);
    if (!video) {
      throw new Error(`Video ${videoId} not found`);
    }

    const videoUrl = video.fileUrl;
    if (!videoUrl) {
      throw new Error("Video URL not found");
    }

    console.log(`[Analysis ${analysisId}] Processing video: ${video.filename}`);

    // Run physics engine
    const result = await runPhysicsEngine(videoUrl, {
      trackingMethod: options.trackingMethod,
      pixelsPerMeter: options.pixelsPerMeter,
      sgWindow: options.sgWindow,
      sgPoly: options.sgPoly,
    });

    if (result.error) {
      throw new Error(result.error);
    }

    console.log(`[Analysis ${analysisId}] Physics engine completed. Frames: ${result.framesTracked}`);

    // Upload HUD GIF to S3
    let hudGifUrl = "";
    let hudGifKey = "";
    if (result.hudGifBase64) {
      const gifBuffer = Buffer.from(result.hudGifBase64, "base64");
      hudGifKey = `hud-gifs/${analysisId}-${nanoid()}.gif`;
      const gifUpload = await storagePut(hudGifKey, gifBuffer, "image/gif");
      hudGifUrl = gifUpload.url;
      console.log(`[Analysis ${analysisId}] HUD GIF uploaded to S3`);
    }

    // Store results in database
    // Convert m/s to mm/s for storage (integer precision)
    await updateAnalysis(analysisId, {
      status: "completed",
      framesTracked: result.framesTracked,
      peakSpeed: result.peakSpeed ? Math.round(result.peakSpeed * 1000) : null,
      meanSpeed: result.meanSpeed ? Math.round(result.meanSpeed * 1000) : null,
      peakAcceleration: result.peakAcceleration ? Math.round(result.peakAcceleration * 1000) : null,
      netDisplacement: result.netDisplacement ? Math.round(result.netDisplacement * 1000) : null,
      pathLength: result.pathLength ? Math.round(result.pathLength * 1000) : null,
      resultsJson: JSON.stringify({
        time: result.time,
        x_m: result.x_m,
        y_m: result.y_m,
        vx: result.vx,
        vy: result.vy,
        speed: result.speed,
        ax: result.ax,
        ay: result.ay,
        accel: result.accel,
      }),
      hudGifKey,
      hudGifUrl,
    });

    console.log(`[Analysis ${analysisId}] Analysis completed successfully`);

    // Clean up temp file if it exists
    try {
      const tempVideoPath = join(tmpdir(), `deltav-${analysisId}.mp4`);
      unlinkSync(tempVideoPath);
    } catch (e) {
      // Ignore cleanup errors
    }
  } catch (error) {
    console.error(`[Analysis ${analysisId}] Processing error:`, error);
    await updateAnalysis(analysisId, {
      status: "failed",
      errorMessage: error instanceof Error ? error.message : "Unknown error",
    });
  }
}
