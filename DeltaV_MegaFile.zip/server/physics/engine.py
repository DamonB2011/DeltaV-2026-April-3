#!/usr/bin/env python3
"""
DeltaV Physics Engine
=====================
Performs kinematics analysis on video files:
- Object tracking (MOG2 or CSRT)
- Savitzky-Golay smoothing
- Numerical differentiation (velocity & acceleration)
- HUD GIF rendering with force vectors
"""

import sys
import json
import cv2
import numpy as np
from scipy.signal import savgol_filter
import base64
import io
from PIL import Image
import argparse


def track_with_mog2(video_path: str):
    """Track using MOG2 background subtraction."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None, None, None

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fgbg = cv2.createBackgroundSubtractorMOG2(
        history=120, varThreshold=40, detectShadows=False
    )

    coords = []
    raw_frames = []
    frame_idx = 0

    # Warm up background model
    for _ in range(min(60, total // 4)):
        ret, f = cap.read()
        if ret:
            fgbg.apply(f)

    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))

    # Track
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        fg_mask = fgbg.apply(frame)
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_DILATE, kernel)

        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if contours:
            largest = max(contours, key=cv2.contourArea)
            if cv2.contourArea(largest) > 80:
                M = cv2.moments(largest)
                if M["m00"] > 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    coords.append((cx, cy))
                    raw_frames.append(frame.copy())
                    frame_idx += 1
                    continue

        if coords:
            coords.append(coords[-1])
        else:
            coords.append((w // 2, h // 2))
        raw_frames.append(frame.copy())
        frame_idx += 1

    cap.release()
    return coords, raw_frames, fps


def smooth_and_differentiate(coords, fps, pixels_per_meter, sg_window, sg_poly):
    """Apply Savitzky-Golay filter and compute velocity/acceleration."""
    xs = np.array([c[0] for c in coords], dtype=float)
    ys = np.array([c[1] for c in coords], dtype=float)
    n = len(xs)

    # Ensure window is odd and valid
    win = min(sg_window | 1, n if n % 2 == 1 else n - 1)
    win = max(win, sg_poly + 2 if (sg_poly + 2) % 2 == 1 else sg_poly + 3)
    poly = min(sg_poly, win - 1)

    # Smooth
    xs_s = savgol_filter(xs, win, poly)
    ys_s = savgol_filter(ys, win, poly)

    # Convert to metres
    x_m = xs_s / pixels_per_meter
    y_m = ys_s / pixels_per_meter

    dt = 1.0 / fps
    time_arr = np.arange(n) * dt

    # Velocity
    vx = np.gradient(x_m, dt)
    vy = np.gradient(y_m, dt)
    speed = np.hypot(vx, vy)

    # Acceleration
    ax = np.gradient(vx, dt)
    ay = np.gradient(vy, dt)
    accel = np.hypot(ax, ay)

    return time_arr, x_m, y_m, vx, vy, speed, ax, ay, accel


def draw_hud_frame(frame, cx, cy, vx, vy, frame_idx, total_frames):
    """Draw HUD overlay on a frame."""
    out = frame.copy()
    h, w = out.shape[:2]

    # Crosshair
    cross_size = 14
    cv2.line(out, (cx - cross_size, cy), (cx + cross_size, cy), (0, 163, 255), 2)
    cv2.line(out, (cx, cy - cross_size), (cx, cy + cross_size), (0, 163, 255), 2)
    cv2.circle(out, (cx, cy), 5, (0, 163, 255), -1)

    # Velocity vector
    speed = np.hypot(vx, vy)
    if speed > 0.5:
        scale = min(80, max(20, speed * 4))
        norm_vx = vx / speed
        norm_vy = vy / speed
        ex = int(cx + norm_vx * scale)
        ey = int(cy + norm_vy * scale)
        ex = max(0, min(w - 1, ex))
        ey = max(0, min(h - 1, ey))
        overlay = out.copy()
        cv2.arrowedLine(overlay, (cx, cy), (ex, ey), (0, 100, 220), 8, tipLength=0.35)
        cv2.addWeighted(overlay, 0.35, out, 0.65, 0, out)
        cv2.arrowedLine(out, (cx, cy), (ex, ey), (0, 200, 255), 2, tipLength=0.35)

    # HUD panel
    panel_w, panel_h = 230, 60
    overlay2 = out.copy()
    cv2.rectangle(overlay2, (8, 8), (8 + panel_w, 8 + panel_h), (5, 10, 25), -1)
    cv2.addWeighted(overlay2, 0.65, out, 0.35, 0, out)
    cv2.rectangle(out, (8, 8), (8 + panel_w, 8 + panel_h), (0, 163, 255), 1)

    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(out, "DeltaV  HUD", (16, 28), font, 0.48, (0, 163, 255), 1, cv2.LINE_AA)
    cv2.putText(out, f"Frame: {frame_idx:04d}/{total_frames:04d}", (16, 44), font, 0.38, (180, 200, 230), 1, cv2.LINE_AA)
    cv2.putText(out, f"Speed: {speed:.1f} px/fr", (130, 44), font, 0.38, (0, 200, 255), 1, cv2.LINE_AA)

    # Progress bar
    bar_y = h - 6
    cv2.line(out, (0, bar_y), (w, bar_y), (20, 30, 50), 3)
    prog_x = int(w * frame_idx / max(total_frames - 1, 1))
    cv2.line(out, (0, bar_y), (prog_x, bar_y), (0, 163, 255), 3)

    return out


def render_hud_video(raw_frames, coords, vx_px, vy_px, max_frames=120, fps=15):
    """Render HUD video as base64-encoded GIF."""
    total = len(raw_frames)
    step = max(1, total // max_frames)
    selected_indices = list(range(0, total, step))[:max_frames]

    hud_frames = []
    for i in selected_indices:
        cx, cy = coords[i]
        vx = vx_px[i] if i < len(vx_px) else 0
        vy = vy_px[i] if i < len(vy_px) else 0
        frame_bgr = raw_frames[i]
        frame_hud = draw_hud_frame(frame_bgr, cx, cy, vx, vy, i, total)
        frame_rgb = cv2.cvtColor(frame_hud, cv2.COLOR_BGR2RGB)
        h, w = frame_rgb.shape[:2]
        max_w = 720
        if w > max_w:
            scale = max_w / w
            frame_rgb = cv2.resize(frame_rgb, (max_w, int(h * scale)))
        hud_frames.append(Image.fromarray(frame_rgb))

    buf = io.BytesIO()
    hud_frames[0].save(
        buf,
        format="GIF",
        save_all=True,
        append_images=hud_frames[1:],
        loop=0,
        duration=int(1000 / fps),
        optimize=False,
    )
    return base64.b64encode(buf.getvalue()).decode()


def main():
    parser = argparse.ArgumentParser(description="DeltaV Physics Engine")
    parser.add_argument("--video", required=True, help="Path to video file")
    parser.add_argument("--tracking-method", default="mog2", help="mog2 or csrt")
    parser.add_argument("--pixels-per-meter", type=int, default=100)
    parser.add_argument("--sg-window", type=int, default=11)
    parser.add_argument("--sg-poly", type=int, default=3)
    parser.add_argument("--hud-fps", type=int, default=15)
    parser.add_argument("--max-hud-frames", type=int, default=120)

    args = parser.parse_args()

    try:
        # Track
        coords, raw_frames, fps = track_with_mog2(args.video)
        if not coords or len(coords) < 10:
            print(json.dumps({"error": "Tracking failed: insufficient motion detected"}))
            sys.exit(1)

        # Math engine
        time_arr, x_m, y_m, vx, vy, speed, ax, ay, accel = smooth_and_differentiate(
            coords, fps, args.pixels_per_meter, args.sg_window, args.sg_poly
        )

        # Pixel-space velocity for HUD
        xs_px = np.array([c[0] for c in coords], dtype=float)
        ys_px = np.array([c[1] for c in coords], dtype=float)
        vx_px = np.gradient(xs_px, 1.0 / fps)
        vy_px = np.gradient(ys_px, 1.0 / fps)

        # HUD GIF
        hud_b64 = render_hud_video(raw_frames, coords, vx_px, vy_px, args.max_hud_frames, args.hud_fps)

        # Summary metrics
        peak_speed = float(np.max(speed))
        mean_speed = float(np.mean(speed))
        peak_accel = float(np.max(accel))
        total_disp = float(np.sqrt((x_m[-1] - x_m[0]) ** 2 + (y_m[-1] - y_m[0]) ** 2))
        path_length = float(np.sum(np.hypot(np.diff(x_m), np.diff(y_m))))

        # Results
        results = {
            "status": "completed",
            "framesTracked": len(coords),
            "fps": float(fps),
            "peakSpeed": peak_speed,
            "meanSpeed": mean_speed,
            "peakAcceleration": peak_accel,
            "netDisplacement": total_disp,
            "pathLength": path_length,
            "time": time_arr.tolist(),
            "x_m": x_m.tolist(),
            "y_m": y_m.tolist(),
            "vx": vx.tolist(),
            "vy": vy.tolist(),
            "speed": speed.tolist(),
            "ax": ax.tolist(),
            "ay": ay.tolist(),
            "accel": accel.tolist(),
            "hudGifBase64": hud_b64,
        }

        print(json.dumps(results))

    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
