import { spawn } from "child_process";
import { join } from "path";

export interface PhysicsEngineResult {
  status: "completed" | "error";
  error?: string;
  framesTracked?: number;
  fps?: number;
  peakSpeed?: number;
  meanSpeed?: number;
  peakAcceleration?: number;
  netDisplacement?: number;
  pathLength?: number;
  time?: number[];
  x_m?: number[];
  y_m?: number[];
  vx?: number[];
  vy?: number[];
  speed?: number[];
  ax?: number[];
  ay?: number[];
  accel?: number[];
  hudGifBase64?: string;
}

export async function runPhysicsEngine(
  videoPath: string,
  options: {
    trackingMethod?: string;
    pixelsPerMeter?: number;
    sgWindow?: number;
    sgPoly?: number;
    hudFps?: number;
    maxHudFrames?: number;
  } = {}
): Promise<PhysicsEngineResult> {
  return new Promise((resolve, reject) => {
    const enginePath = join(__dirname, "engine.py");

    const args: string[] = [
      enginePath,
      "--video",
      videoPath,
      "--tracking-method",
      options.trackingMethod || "mog2",
      "--pixels-per-meter",
      String(options.pixelsPerMeter || 100),
      "--sg-window",
      String(options.sgWindow || 11),
      "--sg-poly",
      String(options.sgPoly || 3),
      "--hud-fps",
      String(options.hudFps || 15),
      "--max-hud-frames",
      String(options.maxHudFrames || 120),
    ];

    const proc = spawn("python3", args);

    let stdout = "";
    let stderr = "";

    if (proc.stdout) {
      proc.stdout.on("data", (data: Buffer) => {
        stdout += data.toString();
      });
    }

    if (proc.stderr) {
      proc.stderr.on("data", (data: Buffer) => {
        stderr += data.toString();
      });
    }

    proc.on("close", (code: number | null) => {
      if (code !== 0) {
        reject(new Error(`Physics engine exited with code ${code}: ${stderr}`));
        return;
      }

      try {
        const result = JSON.parse(stdout) as PhysicsEngineResult;
        resolve(result);
      } catch (e) {
        reject(new Error(`Failed to parse physics engine output: ${stdout}`));
      }
    });

    proc.on("error", (err: Error) => {
      reject(err);
    });
  });
}
