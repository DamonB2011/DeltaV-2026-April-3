import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export interface AnalysisStatus {
  id: number;
  status: "pending" | "processing" | "completed" | "failed";
  progress?: number;
  framesTracked?: number;
  totalFrames?: number;
  peakSpeed?: number;
  meanSpeed?: number;
  peakAcceleration?: number;
  netDisplacement?: number;
  pathLength?: number;
  resultsJson?: string;
  hudGifUrl?: string;
  errorMessage?: string;
}

export function useAnalysisPolling(analysisId: number | null, enabled: boolean = true) {
  const [status, setStatus] = useState<AnalysisStatus | null>(null);
  const [isPolling, setIsPolling] = useState(enabled && analysisId !== null);

  const getAnalysisQuery = trpc.analysis.getAnalysis.useQuery(
    { analysisId: analysisId || 0 },
    {
      enabled: isPolling && analysisId !== null,
      refetchInterval: 2000, // Poll every 2 seconds
    }
  );

  useEffect(() => {
    if (getAnalysisQuery.data) {
      setStatus(getAnalysisQuery.data as AnalysisStatus);

      // Stop polling if analysis is complete or failed
      if (getAnalysisQuery.data.status === "completed" || getAnalysisQuery.data.status === "failed") {
        setIsPolling(false);
      }
    }
  }, [getAnalysisQuery.data]);

  return {
    status,
    isLoading: getAnalysisQuery.isLoading,
    isPolling,
    error: getAnalysisQuery.error,
  };
}
