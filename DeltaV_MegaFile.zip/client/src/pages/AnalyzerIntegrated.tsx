import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Upload, Settings, CheckCircle2, AlertCircle } from "lucide-react";
import { ConfigSidebar, AnalysisConfig } from "@/components/ConfigSidebar";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAnalysisPolling } from "@/hooks/useAnalysisPolling";

export default function AnalyzerIntegrated() {
  const [, navigate] = useLocation();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showConfig, setShowConfig] = useState(true);
  const [analysisId, setAnalysisId] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [config, setConfig] = useState<AnalysisConfig>({
    trackingMethod: "mog2",
    pixelsPerMeter: 100,
    sgWindow: 11,
    sgPoly: 3,
  });

  // tRPC mutations
  const uploadVideoMutation = trpc.analysis.uploadVideo.useMutation();
  const submitAnalysisMutation = trpc.analysis.submitAnalysis.useMutation();

  // Polling for analysis status
  const { status, isPolling } = useAnalysisPolling(analysisId, !!analysisId);

  const handleDragOver = (e: React.DragEvent) => {
    console.log("🎯 Drag over detected");
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    console.log("🎯 Drag leave detected");
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    console.log("🎯 Drop detected");
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    console.log(`📁 Files detected: ${files.length}`);

    if (files.length > 0) {
      const file = files[0];
      console.log(`📄 File name: ${file.name}, Type: ${file.type}, Size: ${file.size}`);

      // Accept ANY file type for now (debug mode)
      setVideoFile(file);
      console.log("✅ File accepted and set");
      toast.success(`File selected: ${file.name}`);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log("🎯 File input change detected");
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      const file = files[0];
      console.log(`📄 File selected: ${file.name}, Type: ${file.type}, Size: ${file.size}`);
      setVideoFile(file);
      console.log("✅ File set from input");
      toast.success(`File selected: ${file.name}`);
    }
  };

  // Manual trigger for file dialog
  const handleSelectFileClick = () => {
    console.log("🎯 Select File button clicked");
    if (fileInputRef.current) {
      console.log("📂 Opening file dialog...");
      fileInputRef.current.click();
    } else {
      console.error("❌ File input ref is null");
    }
  };

  const handleAnalyze = async () => {
    if (!videoFile) {
      toast.error("Please select a video file");
      return;
    }

    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = (e.target?.result as string).split(",")[1];

        try {
          // Upload video
          const uploadResult = await uploadVideoMutation.mutateAsync({
            filename: videoFile.name,
            fileBase64: base64,
            fileSizeBytes: videoFile.size,
          });

          if (!uploadResult.success) {
            throw new Error("Video upload failed");
          }

          toast.success("Video uploaded! Starting analysis...");

          // Submit analysis
          const analysisResult = await submitAnalysisMutation.mutateAsync({
            videoId: uploadResult.videoId,
            trackingMethod: config.trackingMethod,
            pixelsPerMeter: config.pixelsPerMeter,
            sgWindow: config.sgWindow,
            sgPoly: config.sgPoly,
          });

          if (analysisResult.success) {
            setAnalysisId(analysisResult.analysisId);
            toast.success("Analysis submitted! Processing video...");
          }
        } catch (error) {
          toast.error(`Analysis failed: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
      };
      reader.readAsDataURL(videoFile);
    } catch (error) {
      toast.error(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  };

  // If analysis is in progress, show progress screen
  if (analysisId && status) {
    const isComplete = status.status === "completed";
    const isFailed = status.status === "failed";
    const isProcessing = status.status === "processing";

    return (
      <div className="min-h-screen bg-background flex">
        {showConfig && (
          <ConfigSidebar config={config} onConfigChange={setConfig} isAnalyzing={isProcessing} />
        )}

        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <Card className="glass-card max-w-md w-full">
            {isFailed ? (
              <>
                <div className="flex justify-center mb-4">
                  <AlertCircle className="w-12 h-12 text-destructive" />
                </div>
                <h2 className="text-lg font-bold text-foreground text-center mb-2">Analysis Failed</h2>
                <p className="text-sm text-muted-foreground text-center mb-6">{status.errorMessage}</p>
                <Button
                  onClick={() => {
                    setAnalysisId(null);
                    setVideoFile(null);
                  }}
                  className="w-full"
                >
                  Try Again
                </Button>
              </>
            ) : isComplete ? (
              <>
                <div className="flex justify-center mb-4">
                  <CheckCircle2 className="w-12 h-12 text-green-400" />
                </div>
                <h2 className="text-lg font-bold text-foreground text-center mb-2">Analysis Complete!</h2>
                <div className="space-y-2 mb-6 text-sm text-muted-foreground">
                  <p>Frames tracked: {status.framesTracked}</p>
                  <p>Peak speed: {status.peakSpeed?.toFixed(2)} m/s</p>
                  <p>Peak acceleration: {status.peakAcceleration?.toFixed(2)} m/s²</p>
                </div>
                <Button
                  onClick={() => navigate(`/results?id=${analysisId}`)}
                  className="w-full bg-accent hover:bg-accent/90"
                >
                  View Results
                </Button>
              </>
            ) : (
              <>
                <div className="flex justify-center mb-4">
                  <Loader2 className="w-12 h-12 text-accent animate-spin" />
                </div>
                <h2 className="text-lg font-bold text-foreground text-center mb-2">Calculating Kinematics...</h2>
                <p className="text-sm text-muted-foreground text-center mb-4">
                  {config.trackingMethod === "mog2" ? "MOG2 Background Subtraction" : "CSRT Tracking"} • Savitzky-Golay
                  Filter (window={config.sgWindow}, poly={config.sgPoly})
                </p>

                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Progress</span>
                    <span>{status.progress || 0}%</span>
                  </div>
                  <Progress value={status.progress || 0} className="h-2" />
                </div>

                <p className="text-xs text-muted-foreground text-center">
                  This may take a few minutes depending on video length and complexity.
                </p>
              </>
            )}
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      {showConfig && (
        <ConfigSidebar config={config} onConfigChange={setConfig} isAnalyzing={false} />
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto max-w-4xl px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-3xl font-bold text-foreground">Video Analysis</h1>
              <button
                onClick={() => setShowConfig(!showConfig)}
                className="p-2 hover:bg-accent/10 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5 text-accent" />
              </button>
            </div>
            <p className="text-muted-foreground">
              Upload a video and DeltaV will automatically track motion, compute kinematics, and render force vectors.
            </p>
          </div>

          {/* Upload Area */}
          <Card
            className={`glass-card border-2 border-dashed transition-all cursor-pointer ${
              isDragging ? "border-accent bg-accent/10" : "border-accent/30 hover:border-accent/60"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="py-12 text-center">
              <Upload className="w-12 h-12 text-accent mx-auto mb-4" />
              <p className="text-lg font-semibold mb-2">Drop your video here or click to browse</p>
              <p className="text-sm text-muted-foreground mb-6">Supported formats: .mp4, .mov, or any video file</p>

              {/* Hidden file input */}
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileSelect}
                className="hidden"
                id="video-file-input"
              />

              {/* Button that triggers file dialog */}
              <Button
                onClick={handleSelectFileClick}
                variant="outline"
                className="cursor-pointer"
              >
                Select File
              </Button>

              {videoFile && (
                <div className="mt-4 text-sm text-accent">
                  <p className="font-semibold">✅ Selected: {videoFile.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {(videoFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              )}
            </div>
          </Card>

          {/* Configuration Summary */}
          <Card className="glass-card mt-8 bg-accent/5 border-accent/40">
            <h3 className="font-bold text-foreground mb-4">Analysis Configuration</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Tracking Method</p>
                <p className="text-sm font-semibold text-accent">{config.trackingMethod.toUpperCase()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">S-G Window</p>
                <p className="text-sm font-semibold text-accent">{config.sgWindow}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">S-G Polynomial</p>
                <p className="text-sm font-semibold text-accent">{config.sgPoly}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Scale</p>
                <p className="text-sm font-semibold text-accent">{config.pixelsPerMeter} px/m</p>
              </div>
            </div>
          </Card>

          {/* Analyze Button */}
          <div className="mt-8 flex gap-4">
            <Button
              size="lg"
              onClick={handleAnalyze}
              disabled={!videoFile}
              className="flex-1 gap-2 bg-accent hover:bg-accent/90"
            >
              {uploadVideoMutation.isPending || submitAnalysisMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  Start Analysis
                </>
              )}
            </Button>
          </div>

          {/* Info Section */}
          <Card className="glass-card mt-8">
            <h3 className="font-bold text-foreground mb-4">How It Works</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">1. Upload</div>
                <p>Select a video file containing a moving object you want to analyze.</p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">2. Track</div>
                <p>
                  DeltaV uses {config.trackingMethod === "mog2" ? "MOG2 background subtraction" : "CSRT tracking"} to
                  automatically detect and track the object's center-of-mass across all frames.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">3. Smooth</div>
                <p>
                  A Savitzky-Golay filter (window={config.sgWindow}, poly={config.sgPoly}) removes noise from the
                  tracking data while preserving signal shape.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">4. Compute</div>
                <p>
                  Numerical differentiation calculates velocity and acceleration vectors. The scale calibration
                  ({config.pixelsPerMeter} px/m) converts pixel coordinates to real-world SI units.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">5. Visualize</div>
                <p>
                  View the force vector HUD overlay, three synchronized kinematics charts, and export raw data as CSV.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
