import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Upload, Settings } from "lucide-react";
import { ConfigSidebar, AnalysisConfig } from "@/components/ConfigSidebar";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Analyzer() {
  const [, navigate] = useLocation();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showConfig, setShowConfig] = useState(true);

  const [config, setConfig] = useState<AnalysisConfig>({
    trackingMethod: "mog2",
    pixelsPerMeter: 100,
    sgWindow: 11,
    sgPoly: 3,
  });

  // tRPC mutations
  const uploadVideoMutation = trpc.analysis.uploadVideo.useMutation();
  const submitAnalysisMutation = trpc.analysis.submitAnalysis.useMutation();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.includes("video")) {
        setVideoFile(file);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      setVideoFile(files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!videoFile) {
      toast.error("Please select a video file");
      return;
    }

    setIsAnalyzing(true);

    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = (e.target?.result as string).split(",")[1];

        // Upload video
        const uploadResult = await uploadVideoMutation.mutateAsync({
          filename: videoFile.name,
          fileBase64: base64,
          fileSizeBytes: videoFile.size,
        });

        if (!uploadResult.success) {
          throw new Error("Video upload failed");
        }

        // Submit analysis
        const analysisResult = await submitAnalysisMutation.mutateAsync({
          videoId: uploadResult.videoId,
          trackingMethod: config.trackingMethod,
          pixelsPerMeter: config.pixelsPerMeter,
          sgWindow: config.sgWindow,
          sgPoly: config.sgPoly,
        });

        if (analysisResult.success) {
          toast.success("Analysis submitted! Redirecting to results...");
          setTimeout(() => {
            navigate(`/results?id=${analysisResult.analysisId}`);
          }, 1500);
        }
      };
      reader.readAsDataURL(videoFile);
    } catch (error) {
      toast.error(`Analysis failed: ${error instanceof Error ? error.message : "Unknown error"}`);
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      {showConfig && (
        <ConfigSidebar config={config} onConfigChange={setConfig} isAnalyzing={isAnalyzing} />
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto max-w-4xl px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-3xl font-bold text-foreground">Video Analysis</h1>
              <button
                onClick={() => setShowConfig(!showConfig)}
                className="p-2 hover:bg-accent/10 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5 text-accent" />
              </button>
            </div>
            <p className="text-muted-foreground">
              Upload a video and DeltaV will automatically track motion, compute kinematics, and render force vectors.
            </p>
          </div>

          {/* Upload Area */}
          <Card
            className={`glass-card border-2 border-dashed transition-all cursor-pointer ${
              isDragging ? "border-accent bg-accent/10" : "border-accent/30 hover:border-accent/60"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="py-12 text-center">
              <Upload className="w-12 h-12 text-accent mx-auto mb-4" />
              <p className="text-lg font-semibold mb-2">Drop your video here or click to browse</p>
              <p className="text-sm text-muted-foreground mb-6">Supported formats: .mp4, .mov</p>
              <label>
                <input
                  type="file"
                  accept="video/mp4,video/quicktime"
                  onChange={handleFileSelect}
                  disabled={isAnalyzing}
                  className="hidden"
                />
                <Button variant="outline" disabled={isAnalyzing} className="cursor-pointer">
                  Select File
                </Button>
              </label>
              {videoFile && (
                <div className="mt-4 text-sm text-accent">
                  <p className="font-semibold">Selected: {videoFile.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {(videoFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              )}
            </div>
          </Card>

          {/* Configuration Summary */}
          <Card className="glass-card mt-8 bg-accent/5 border-accent/40">
            <h3 className="font-bold text-foreground mb-4">Analysis Configuration</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Tracking Method</p>
                <p className="text-sm font-semibold text-accent">{config.trackingMethod.toUpperCase()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">S-G Window</p>
                <p className="text-sm font-semibold text-accent">{config.sgWindow}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">S-G Polynomial</p>
                <p className="text-sm font-semibold text-accent">{config.sgPoly}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Scale</p>
                <p className="text-sm font-semibold text-accent">{config.pixelsPerMeter} px/m</p>
              </div>
            </div>
          </Card>

          {/* Analyze Button */}
          <div className="mt-8 flex gap-4">
            <Button
              size="lg"
              onClick={handleAnalyze}
              disabled={!videoFile || isAnalyzing}
              className="flex-1 gap-2 bg-accent hover:bg-accent/90"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  Start Analysis
                </>
              )}
            </Button>
          </div>

          {/* Info Section */}
          <Card className="glass-card mt-8">
            <h3 className="font-bold text-foreground mb-4">How It Works</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">1. Upload</div>
                <p>Select a video file containing a moving object you want to analyze.</p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">2. Track</div>
                <p>
                  DeltaV uses {config.trackingMethod === "mog2" ? "MOG2 background subtraction" : "CSRT tracking"} to
                  automatically detect and track the object's center-of-mass across all frames.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">3. Smooth</div>
                <p>
                  A Savitzky-Golay filter (window={config.sgWindow}, poly={config.sgPoly}) removes noise from the
                  tracking data while preserving signal shape.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">4. Compute</div>
                <p>
                  Numerical differentiation calculates velocity and acceleration vectors. The scale calibration
                  ({config.pixelsPerMeter} px/m) converts pixel coordinates to real-world SI units.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="text-accent font-bold min-w-fit">5. Visualize</div>
                <p>
                  View the force vector HUD overlay, three synchronized kinematics charts, and export raw data as CSV.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
