import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Zap, Upload, TrendingUp, BarChart3, ArrowRight } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.includes("video")) {
        setVideoFile(file);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      setVideoFile(files[0]);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="hero-wrapper container mx-auto max-w-6xl">
        <div className="mb-6 inline-block px-4 py-1 rounded-full bg-accent/10 border border-accent/30">
          <span className="text-xs font-bold text-accent uppercase tracking-widest">
            ⚡ AI-Powered Physics Analysis
          </span>
        </div>
        <h1 className="hero-title text-5xl md:text-6xl mb-6">
          The AI-Powered Kinematics Engine
          <br />
          for Real-World Physics.
        </h1>
        <p className="hero-subtitle text-lg md:text-xl">
          Upload any video and DeltaV will automatically track moving objects, apply Savitzky-Golay smoothing,
          compute velocity and acceleration via numerical differentiation, and render interactive physics dashboards
          — all in real time.
        </p>
        <div className="flex flex-wrap gap-8 mt-8">
          <div>
            <div className="text-2xl font-bold text-accent">CSRT</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Tracking Algorithm</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-accent">S-G</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Signal Filter</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-accent">∂²x/∂t²</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Differentiation</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-accent">3D</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Plotly Charts</div>
          </div>
        </div>
      </section>

      {/* Upload Section */}
      <section className="container mx-auto max-w-6xl mb-12">
        <div className="section-header">01 — Upload Video</div>

        {!isAuthenticated ? (
          <div className="glass-card text-center py-12">
            <p className="text-muted-foreground mb-6">Sign in to start analysing videos</p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-accent hover:bg-accent/90">
                Sign In with Manus
              </Button>
            </a>
          </div>
        ) : videoFile ? (
          <div className="glass-card text-center py-12">
            <p className="text-lg font-semibold text-foreground mb-2">Ready to analyze: {videoFile.name}</p>
            <p className="text-sm text-muted-foreground mb-6">{(videoFile.size / 1024 / 1024).toFixed(2)} MB</p>
            <Button
              size="lg"
              onClick={() => navigate("/analyzer")}
              className="bg-accent hover:bg-accent/90 gap-2"
            >
              Proceed to Analysis <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div
            className={`glass-card border-2 border-dashed transition-all ${
              isDragging ? "border-accent bg-accent/10" : "border-accent/30 hover:border-accent/60"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="py-12 text-center">
              <Upload className="w-12 h-12 text-accent mx-auto mb-4" />
              <p className="text-lg font-semibold mb-2">Drop your video here, the "Select File" Button is currently bugged</p>
              <p className="text-sm text-muted-foreground mb-6">Supported formats: .mp4, .mov</p>
              <label>
                <input
                  type="file"
                  accept="video/mp4,video/quicktime"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <Button variant="outline" className="cursor-pointer">
                  Select File
                </Button>
              </label>
            </div>
          </div>
        )}
      </section>

      {/* Features Section */}
      <section className="container mx-auto max-w-6xl mb-16">
        <div className="section-header">Platform Capabilities</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-card-sm">
            <TrendingUp className="w-6 h-6 text-accent mb-3" />
            <h3 className="font-bold text-foreground mb-2">Intelligent Tracking</h3>
            <p className="text-sm text-muted-foreground">
              MOG2 background subtraction automatically isolates and tracks the dominant moving object across all
              frames. CSRT mode provides sub-pixel accuracy for user-defined regions.
            </p>
          </div>
          <div className="glass-card-sm">
            <Zap className="w-6 h-6 text-accent mb-3" />
            <h3 className="font-bold text-foreground mb-2">Elite Math Engine</h3>
            <p className="text-sm text-muted-foreground">
              Savitzky-Golay filtering removes sensor noise while preserving signal shape. Central-difference numerical
              differentiation converts position data into velocity and acceleration vectors.
            </p>
          </div>
          <div className="glass-card-sm">
            <BarChart3 className="w-6 h-6 text-accent mb-3" />
            <h3 className="font-bold text-foreground mb-2">Interactive Dashboard</h3>
            <p className="text-sm text-muted-foreground">
              Three synchronized Plotly charts display Position, Velocity, and Acceleration vs. Time. Hover for
              precise values, zoom, pan, and export as PNG or CSV.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
