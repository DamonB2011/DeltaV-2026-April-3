import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, ArrowLeft, Loader2 } from "lucide-react";
import { KinematicsCharts, KinematicsData } from "@/components/KinematicsCharts";

interface AnalysisResult {
  id: number;
  status: "pending" | "processing" | "completed" | "failed";
  framesTracked?: number;
  fps?: number;
  peakSpeed?: number;
  meanSpeed?: number;
  peakAcceleration?: number;
  netDisplacement?: number;
  pathLength?: number;
  resultsJson?: string;
  hudGifUrl?: string;
  errorMessage?: string;
}

export default function AnalysisResults() {
  const [location, navigate] = useLocation();
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [kinematicsData, setKinematicsData] = useState<KinematicsData | null>(null);

  // Extract analysis ID from URL query params
  const analysisId = new URLSearchParams(location.split("?")[1]).get("id");

  useEffect(() => {
    // Simulate fetching analysis results
    // In real app, use tRPC: trpc.analysis.getAnalysis.useQuery({ analysisId })
    const mockAnalysis: AnalysisResult = {
      id: parseInt(analysisId || "1", 10),
      status: "completed",
      framesTracked: 120,
      fps: 30,
      peakSpeed: 5.42,
      meanSpeed: 2.18,
      peakAcceleration: 9.81,
      netDisplacement: 3.42,
      pathLength: 8.76,
      hudGifUrl: "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
      resultsJson: JSON.stringify({
        time: Array.from({ length: 120 }, (_, i) => i / 30),
        x_m: Array.from({ length: 120 }, (_, i) => Math.sin(i / 20) * 2),
        y_m: Array.from({ length: 120 }, (_, i) => (i / 120) * 3),
        vx: Array.from({ length: 120 }, (_, i) => Math.cos(i / 20) * 0.5),
        vy: Array.from({ length: 120 }, (_, i) => 0.025),
        speed: Array.from({ length: 120 }, (_, i) => Math.sqrt(Math.cos(i / 20) ** 2 * 0.25 + 0.000625)),
        ax: Array.from({ length: 120 }, (_, i) => -Math.sin(i / 20) * 0.1),
        ay: Array.from({ length: 120 }, (_, i) => 0),
        accel: Array.from({ length: 120 }, (_, i) => Math.abs(-Math.sin(i / 20) * 0.1)),
      }),
    };

    setAnalysis(mockAnalysis);

    if (mockAnalysis.resultsJson) {
      try {
        const parsed = JSON.parse(mockAnalysis.resultsJson);
        setKinematicsData(parsed);
      } catch (e) {
        console.error("Failed to parse kinematics data:", e);
      }
    }

    setIsLoading(false);
  }, [analysisId]);

  const handleExportCSV = () => {
    if (!kinematicsData) return;

    const rows = [
      ["Time (s)", "X (m)", "Y (m)", "Vx (m/s)", "Vy (m/s)", "Speed (m/s)", "Ax (m/s²)", "Ay (m/s²)", "Accel (m/s²)"],
    ];

    for (let i = 0; i < kinematicsData.time.length; i++) {
      rows.push([
        kinematicsData.time[i]?.toFixed(3) || "0",
        kinematicsData.x_m[i]?.toFixed(3) || "0",
        kinematicsData.y_m[i]?.toFixed(3) || "0",
        kinematicsData.vx[i]?.toFixed(3) || "0",
        kinematicsData.vy[i]?.toFixed(3) || "0",
        kinematicsData.speed[i]?.toFixed(3) || "0",
        kinematicsData.ax[i]?.toFixed(3) || "0",
        kinematicsData.ay[i]?.toFixed(3) || "0",
        kinematicsData.accel[i]?.toFixed(3) || "0",
      ]);
    }

    const csv = rows.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `deltav-analysis-${analysis?.id}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-accent animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading analysis results...</p>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Analysis not found</p>
          <Button onClick={() => navigate("/")} variant="outline">
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  if (analysis.status === "failed") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="glass-card max-w-md">
          <h2 className="text-lg font-bold text-destructive mb-2">Analysis Failed</h2>
          <p className="text-muted-foreground mb-4">{analysis.errorMessage || "Unknown error occurred"}</p>
          <Button onClick={() => navigate("/")} variant="outline" className="w-full">
            Return to Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border sticky top-0 z-10 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 hover:bg-accent/10 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-accent" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Analysis Results</h1>
              <p className="text-sm text-muted-foreground">Analysis #{analysis.id}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {analysis.status === "processing" && (
              <div className="flex items-center gap-2 text-accent">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm font-semibold">Processing...</span>
              </div>
            )}
            {analysis.status === "completed" && (
              <span className="text-sm font-semibold text-green-400">✓ Completed</span>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto max-w-7xl px-4 py-8">
        {analysis.status === "processing" ? (
          <div className="text-center py-12">
            <Loader2 className="w-12 h-12 text-accent animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Analysis is processing. This may take a few minutes...</p>
          </div>
        ) : (
          <Tabs defaultValue="hud" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-card border border-border">
              <TabsTrigger value="hud">Force Vector HUD</TabsTrigger>
              <TabsTrigger value="charts">Kinematics Charts</TabsTrigger>
              <TabsTrigger value="data">Raw Data</TabsTrigger>
            </TabsList>

            {/* HUD Video Tab */}
            <TabsContent value="hud" className="space-y-4">
              <Card className="glass-card">
                <h2 className="text-lg font-bold text-foreground mb-4">Force Vector Overlay Video</h2>
                {analysis.hudGifUrl ? (
                  <div className="bg-black rounded-lg overflow-hidden">
                    <img
                      src={analysis.hudGifUrl}
                      alt="HUD Video with Force Vectors"
                      className="w-full h-auto"
                    />
                  </div>
                ) : (
                  <div className="bg-accent/5 border border-accent/20 rounded-lg p-8 text-center">
                    <p className="text-muted-foreground">HUD video not available</p>
                  </div>
                )}
                <div className="mt-4 p-4 bg-accent/5 border border-accent/20 rounded-lg">
                  <p className="text-xs font-semibold text-accent mb-2">HUD Display Information</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>
                      <span className="text-accent">⊕</span> Crosshair marks the center-of-mass of the tracked object
                    </li>
                    <li>
                      <span className="text-accent">→</span> Blue arrow shows velocity vector (direction & magnitude)
                    </li>
                    <li>
                      <span className="text-accent">▯</span> Progress bar at bottom indicates frame position
                    </li>
                    <li>
                      <span className="text-accent">◆</span> HUD panel shows frame count and instantaneous speed
                    </li>
                  </ul>
                </div>
              </Card>
            </TabsContent>

            {/* Charts Tab */}
            <TabsContent value="charts" className="space-y-4">
              {kinematicsData ? (
                <KinematicsCharts data={kinematicsData} />
              ) : (
                <Card className="glass-card text-center py-12">
                  <p className="text-muted-foreground">No kinematics data available</p>
                </Card>
              )}
            </TabsContent>

            {/* Raw Data Tab */}
            <TabsContent value="data" className="space-y-4">
              <Card className="glass-card">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-foreground">Raw Kinematics Data</h2>
                  <Button onClick={handleExportCSV} variant="outline" size="sm" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export CSV
                  </Button>
                </div>

                {/* Summary Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                  <div className="metric-card">
                    <div className="metric-value">{analysis.framesTracked}</div>
                    <div className="metric-label">Frames Tracked</div>
                  </div>
                  <div className="metric-card">
                    <div className="metric-value">{analysis.peakSpeed?.toFixed(2)}</div>
                    <div className="metric-unit">m/s</div>
                    <div className="metric-label">Peak Speed</div>
                  </div>
                  <div className="metric-card">
                    <div className="metric-value">{analysis.meanSpeed?.toFixed(2)}</div>
                    <div className="metric-unit">m/s</div>
                    <div className="metric-label">Mean Speed</div>
                  </div>
                  <div className="metric-card">
                    <div className="metric-value">{analysis.peakAcceleration?.toFixed(2)}</div>
                    <div className="metric-unit">m/s²</div>
                    <div className="metric-label">Peak Accel</div>
                  </div>
                  <div className="metric-card">
                    <div className="metric-value">{analysis.netDisplacement?.toFixed(2)}</div>
                    <div className="metric-unit">m</div>
                    <div className="metric-label">Net Displacement</div>
                  </div>
                  <div className="metric-card">
                    <div className="metric-value">{analysis.pathLength?.toFixed(2)}</div>
                    <div className="metric-unit">m</div>
                    <div className="metric-label">Path Length</div>
                  </div>
                </div>

                {/* Data Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 px-3 text-muted-foreground font-semibold">Time (s)</th>
                        <th className="text-right py-2 px-3 text-muted-foreground font-semibold">X (m)</th>
                        <th className="text-right py-2 px-3 text-muted-foreground font-semibold">Y (m)</th>
                        <th className="text-right py-2 px-3 text-muted-foreground font-semibold">Speed (m/s)</th>
                        <th className="text-right py-2 px-3 text-muted-foreground font-semibold">Accel (m/s²)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {kinematicsData?.time.map((t, i) => (
                        <tr key={i} className="border-b border-border/50 hover:bg-accent/5 transition-colors">
                          <td className="py-2 px-3 text-foreground">{t.toFixed(3)}</td>
                          <td className="text-right py-2 px-3 text-accent">{kinematicsData.x_m[i]?.toFixed(3)}</td>
                          <td className="text-right py-2 px-3 text-accent">{kinematicsData.y_m[i]?.toFixed(3)}</td>
                          <td className="text-right py-2 px-3 text-green-400">{kinematicsData.speed[i]?.toFixed(3)}</td>
                          <td className="text-right py-2 px-3 text-orange-400">{kinematicsData.accel[i]?.toFixed(3)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
