import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from "recharts";
import { Card } from "@/components/ui/card";

export interface KinematicsData {
  time: number[];
  x_m: number[];
  y_m: number[];
  vx: number[];
  vy: number[];
  speed: number[];
  ax: number[];
  ay: number[];
  accel: number[];
}

interface KinematicsChartsProps {
  data: KinematicsData;
}

export function KinematicsCharts({ data }: KinematicsChartsProps) {
  // Prepare data for Recharts
  const chartData = useMemo(() => {
    return data.time.map((t, i) => ({
      time: t.toFixed(2),
      x_m: parseFloat(data.x_m[i]?.toFixed(3) || "0"),
      y_m: parseFloat(data.y_m[i]?.toFixed(3) || "0"),
      vx: parseFloat(data.vx[i]?.toFixed(3) || "0"),
      vy: parseFloat(data.vy[i]?.toFixed(3) || "0"),
      speed: parseFloat(data.speed[i]?.toFixed(3) || "0"),
      ax: parseFloat(data.ax[i]?.toFixed(3) || "0"),
      ay: parseFloat(data.ay[i]?.toFixed(3) || "0"),
      accel: parseFloat(data.accel[i]?.toFixed(3) || "0"),
    }));
  }, [data]);

  // Trajectory data for 2D map
  const trajectoryData = useMemo(() => {
    return data.x_m.map((x, i) => ({
      x: parseFloat(x.toFixed(3)),
      y: parseFloat(data.y_m[i]?.toFixed(3) || "0"),
      speed: parseFloat(data.speed[i]?.toFixed(3) || "0"),
    }));
  }, [data]);

  const maxSpeed = Math.max(...data.speed);
  const maxAccel = Math.max(...data.accel);

  return (
    <div className="space-y-6">
      {/* Position vs Time */}
      <Card className="glass-card">
        <h3 className="text-sm font-bold text-foreground mb-4">Position vs. Time</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 163, 255, 0.1)" />
            <XAxis dataKey="time" stroke="rgba(226, 232, 240, 0.5)" />
            <YAxis stroke="rgba(226, 232, 240, 0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(10, 20, 40, 0.95)",
                border: "1px solid rgba(0, 163, 255, 0.3)",
                borderRadius: "0.5rem",
              }}
              labelStyle={{ color: "#e2e8f0" }}
            />
            <Legend />
            <Line type="monotone" dataKey="x_m" stroke="#00a3ff" dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="y_m" stroke="#00e5b0" dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-3 text-xs text-muted-foreground">
          X range: {Math.min(...data.x_m).toFixed(2)} to {Math.max(...data.x_m).toFixed(2)} m | Y range:{" "}
          {Math.min(...data.y_m).toFixed(2)} to {Math.max(...data.y_m).toFixed(2)} m
        </div>
      </Card>

      {/* Velocity vs Time */}
      <Card className="glass-card">
        <h3 className="text-sm font-bold text-foreground mb-4">Velocity vs. Time</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 163, 255, 0.1)" />
            <XAxis dataKey="time" stroke="rgba(226, 232, 240, 0.5)" />
            <YAxis stroke="rgba(226, 232, 240, 0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(10, 20, 40, 0.95)",
                border: "1px solid rgba(0, 163, 255, 0.3)",
                borderRadius: "0.5rem",
              }}
              labelStyle={{ color: "#e2e8f0" }}
            />
            <Legend />
            <Line type="monotone" dataKey="vx" stroke="#00a3ff" dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="vy" stroke="#00e5b0" dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="speed" stroke="#ff6b35" strokeWidth={2} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-3 text-xs text-muted-foreground">
          Peak speed: {maxSpeed.toFixed(2)} m/s | Mean speed: {(data.speed.reduce((a, b) => a + b, 0) / data.speed.length).toFixed(2)} m/s
        </div>
      </Card>

      {/* Acceleration vs Time */}
      <Card className="glass-card">
        <h3 className="text-sm font-bold text-foreground mb-4">Acceleration vs. Time</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 163, 255, 0.1)" />
            <XAxis dataKey="time" stroke="rgba(226, 232, 240, 0.5)" />
            <YAxis stroke="rgba(226, 232, 240, 0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(10, 20, 40, 0.95)",
                border: "1px solid rgba(0, 163, 255, 0.3)",
                borderRadius: "0.5rem",
              }}
              labelStyle={{ color: "#e2e8f0" }}
            />
            <Legend />
            <Line type="monotone" dataKey="ax" stroke="#00a3ff" dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="ay" stroke="#00e5b0" dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="accel" stroke="#ff3d71" strokeWidth={2} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
        <div className="mt-3 text-xs text-muted-foreground">
          Peak acceleration: {maxAccel.toFixed(2)} m/s² | Mean acceleration:{" "}
          {(data.accel.reduce((a, b) => a + b, 0) / data.accel.length).toFixed(2)} m/s²
        </div>
      </Card>

      {/* 2D Trajectory Map */}
      <Card className="glass-card">
        <h3 className="text-sm font-bold text-foreground mb-4">2D Trajectory Map (Colored by Speed)</h3>
        <ResponsiveContainer width="100%" height={350}>
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 163, 255, 0.1)" />
            <XAxis dataKey="x" name="X (m)" stroke="rgba(226, 232, 240, 0.5)" />
            <YAxis dataKey="y" name="Y (m)" stroke="rgba(226, 232, 240, 0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(10, 20, 40, 0.95)",
                border: "1px solid rgba(0, 163, 255, 0.3)",
                borderRadius: "0.5rem",
              }}
              labelStyle={{ color: "#e2e8f0" }}
              cursor={{ strokeDasharray: "3 3" }}
            />
            <Scatter
              name="Trajectory"
              data={trajectoryData}
              fill="#00a3ff"
              shape="circle"
              isAnimationActive={false}
            />
            {/* Start marker */}
            {trajectoryData.length > 0 && (
              <Scatter
                name="Start"
                data={[trajectoryData[0]]}
                fill="#00e5b0"
                shape="diamond"
                isAnimationActive={false}
              />
            )}
            {/* End marker */}
            {trajectoryData.length > 0 && (
              <Scatter
                name="End"
                data={[trajectoryData[trajectoryData.length - 1]]}
                fill="#ff6b35"
                shape="cross"
                isAnimationActive={false}
              />
            )}
          </ScatterChart>
        </ResponsiveContainer>
        <div className="mt-3 text-xs text-muted-foreground">
          Total points: {trajectoryData.length} | X range: {Math.min(...data.x_m).toFixed(2)} to{" "}
          {Math.max(...data.x_m).toFixed(2)} m | Y range: {Math.min(...data.y_m).toFixed(2)} to{" "}
          {Math.max(...data.y_m).toFixed(2)} m
        </div>
      </Card>
    </div>
  );
}
