import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { ChevronDown, ChevronUp } from "lucide-react";

export interface AnalysisConfig {
  trackingMethod: "mog2" | "csrt";
  pixelsPerMeter: number;
  sgWindow: number;
  sgPoly: number;
}

interface ConfigSidebarProps {
  config: AnalysisConfig;
  onConfigChange: (config: AnalysisConfig) => void;
  isAnalyzing?: boolean;
}

export function ConfigSidebar({ config, onConfigChange, isAnalyzing = false }: ConfigSidebarProps) {
  const [expandedSections, setExpandedSections] = useState({
    tracking: true,
    filtering: true,
    calibration: true,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleTrackingMethodChange = (value: "mog2" | "csrt") => {
    onConfigChange({ ...config, trackingMethod: value });
  };

  const handlePixelsPerMeterChange = (value: string) => {
    const num = parseInt(value, 10);
    if (!isNaN(num) && num > 0) {
      onConfigChange({ ...config, pixelsPerMeter: num });
    }
  };

  const handleSGWindowChange = (value: number[]) => {
    const val = value[0];
    const odd = val % 2 === 0 ? val + 1 : val;
    onConfigChange({ ...config, sgWindow: odd });
  };

  const handleSGPolyChange = (value: number[]) => {
    onConfigChange({ ...config, sgPoly: value[0] });
  };

  return (
    <div className="w-80 bg-background border-r border-border p-4 space-y-4 overflow-y-auto">
      <div className="mb-6">
        <h2 className="text-lg font-bold text-foreground">Analysis Config</h2>
        <p className="text-xs text-muted-foreground mt-1">Customize tracking and filtering parameters</p>
      </div>

      {/* Tracking Method Section */}
      <div className="glass-card-sm">
        <button
          onClick={() => toggleSection("tracking")}
          className="w-full flex items-center justify-between py-2 px-0 hover:opacity-80 transition-opacity"
        >
          <h3 className="font-semibold text-sm text-foreground">Tracking Method</h3>
          {expandedSections.tracking ? (
            <ChevronUp className="w-4 h-4 text-accent" />
          ) : (
            <ChevronDown className="w-4 h-4 text-accent" />
          )}
        </button>

        {expandedSections.tracking && (
          <div className="mt-3 space-y-3 pt-3 border-t border-border">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-foreground">Algorithm</Label>
              <Select value={config.trackingMethod} onValueChange={handleTrackingMethodChange} disabled={isAnalyzing}>
                <SelectTrigger className="h-9 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mog2">
                    <span className="text-sm">MOG2 (Auto-detect)</span>
                  </SelectItem>
                  <SelectItem value="csrt">
                    <span className="text-sm">CSRT (Manual ROI)</span>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {config.trackingMethod === "mog2"
                  ? "Automatic background subtraction for dominant moving objects"
                  : "Manual region-of-interest tracking with sub-pixel accuracy"}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Savitzky-Golay Filter Section */}
      <div className="glass-card-sm">
        <button
          onClick={() => toggleSection("filtering")}
          className="w-full flex items-center justify-between py-2 px-0 hover:opacity-80 transition-opacity"
        >
          <h3 className="font-semibold text-sm text-foreground">S-G Filter</h3>
          {expandedSections.filtering ? (
            <ChevronUp className="w-4 h-4 text-accent" />
          ) : (
            <ChevronDown className="w-4 h-4 text-accent" />
          )}
        </button>

        {expandedSections.filtering && (
          <div className="mt-3 space-y-4 pt-3 border-t border-border">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-xs font-semibold text-foreground">Window Length</Label>
                <span className="text-xs font-mono text-accent bg-accent/10 px-2 py-1 rounded">
                  {config.sgWindow}
                </span>
              </div>
              <Slider
                value={[config.sgWindow]}
                onValueChange={handleSGWindowChange}
                min={5}
                max={51}
                step={2}
                disabled={isAnalyzing}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">Smoothing window (must be odd, 5-51)</p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-xs font-semibold text-foreground">Polynomial Order</Label>
                <span className="text-xs font-mono text-accent bg-accent/10 px-2 py-1 rounded">
                  {config.sgPoly}
                </span>
              </div>
              <Slider
                value={[config.sgPoly]}
                onValueChange={handleSGPolyChange}
                min={1}
                max={5}
                step={1}
                disabled={isAnalyzing}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">Polynomial degree (1-5, lower = more smoothing)</p>
            </div>
          </div>
        )}
      </div>

      {/* Scale Calibration Section */}
      <div className="glass-card-sm">
        <button
          onClick={() => toggleSection("calibration")}
          className="w-full flex items-center justify-between py-2 px-0 hover:opacity-80 transition-opacity"
        >
          <h3 className="font-semibold text-sm text-foreground">Scale Calibration</h3>
          {expandedSections.calibration ? (
            <ChevronUp className="w-4 h-4 text-accent" />
          ) : (
            <ChevronDown className="w-4 h-4 text-accent" />
          )}
        </button>

        {expandedSections.calibration && (
          <div className="mt-3 space-y-3 pt-3 border-t border-border">
            <div className="space-y-2">
              <Label className="text-xs font-semibold text-foreground">Pixels per Meter</Label>
              <Input
                type="number"
                value={config.pixelsPerMeter}
                onChange={(e) => handlePixelsPerMeterChange(e.target.value)}
                disabled={isAnalyzing}
                min={1}
                className="h-9 text-sm"
                placeholder="100"
              />
              <p className="text-xs text-muted-foreground">
                Conversion factor (e.g., 100 pixels = 1 meter). Adjust based on video resolution and object size.
              </p>
            </div>

            <div className="bg-accent/5 border border-accent/20 rounded p-3 space-y-2">
              <p className="text-xs font-semibold text-accent">Calibration Tips</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Measure a known distance in the video</li>
                <li>• Count pixels between reference points</li>
                <li>• Calculate: pixels / meters = calibration</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Summary */}
      <div className="glass-card-sm border-accent/40 bg-accent/5">
        <p className="text-xs text-muted-foreground mb-2">Current Configuration</p>
        <div className="space-y-1 text-xs font-mono text-foreground">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tracking:</span>
            <span className="text-accent">{config.trackingMethod.toUpperCase()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">S-G Window:</span>
            <span className="text-accent">{config.sgWindow}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">S-G Poly:</span>
            <span className="text-accent">{config.sgPoly}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Scale:</span>
            <span className="text-accent">{config.pixelsPerMeter} px/m</span>
          </div>
        </div>
      </div>
    </div>
  );
}
